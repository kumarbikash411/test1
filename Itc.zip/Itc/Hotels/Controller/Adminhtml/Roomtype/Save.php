<?php
/**
 *
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Itc\Hotels\Controller\Adminhtml\Roomtype;

use Magento\Backend\App\Action;
use Itc\Hotels\Model\Roomtype;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\Exception\LocalizedException;

class Save extends \Magento\Backend\App\Action
{
    /**
     * Authorization level of a basic admin session
     *
     * @see _isAllowed()
     */
    const ADMIN_RESOURCE = 'Itc_Hotels::save';

   
    protected $dataPersistor;

    /**
     * @param Action\Context $context
     * @param PostDataProcessor $dataProcessor
     * @param DataPersistorInterface $dataPersistor
     */
    public function __construct(
        Action\Context $context,
        DataPersistorInterface $dataPersistor
    ) {
        $this->dataPersistor = $dataPersistor;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
		//$roomname = $this->getRequest()->getParams();
		//print_r($roomname);exit;
        $rtypeid = $this->getRequest()->getParam('rtype_id');
		$rtypename = $this->getRequest()->getParam('rtype_name');
		$rtypedesc = $this->getRequest()->getParam('rtype_descrtype_desc');
	
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
            $model = $this->_objectManager->create('Itc\Hotels\Model\Roomtype');
            $model->setData('rtype_id', $rtypeid);
            $model->setData('rtype_name', $rtypename);
            $model->setData('rtype_descrtype_desc', $rtypedesc);
			
            $model->save();
            return $resultRedirect->setPath('*/*/');
    }
}
