<?php
/**
 *
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Itc\Hotels\Controller\Adminhtml\Amenity;

use Magento\Backend\App\Action;
use Itc\Hotels\Model\Amenity;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\Exception\LocalizedException;

class Save extends \Magento\Backend\App\Action
{
    /**
     * Authorization level of a basic admin session
     *
     * @see _isAllowed()
     */
    const ADMIN_RESOURCE = 'Itc_Hotels::save';

   
    protected $dataPersistor;

    /**
     * @param Action\Context $context
     * @param PostDataProcessor $dataProcessor
     * @param DataPersistorInterface $dataPersistor
     */
    public function __construct(
        Action\Context $context,
        DataPersistorInterface $dataPersistor
    ) {
        $this->dataPersistor = $dataPersistor;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        
    // $amenities_name = $this->getRequest()->getParams();
        
	//$amenities_name = $this->getRequest()->getParams();
      
		//print_r($amenities_name);exit;  
        
                  $amenities_name = $this->getRequest()->getParam('amenities_name');
		
		$amenities_decs = $this->getRequest()->getParam('amenities_decs');
		
                	$amenities_decs1 = $this->getRequest()->getParam('logo');
             
		
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        
            $model = $this->_objectManager->create('Itc\Hotels\Model\Amenity');
            
                      $model->setData('amenities_name', $amenities_name);
			
			$model->setData('amenities_decs', $amenities_decs);
                        $model->setData('logo', $amenities_decs1);
                    
                
			
			
                       $model->save();
            return $resultRedirect->setPath('*/*/');
    }
}
