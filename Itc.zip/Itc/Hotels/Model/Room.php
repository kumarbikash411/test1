<?php
/**
 * Hello World
    *
    * @category    QaisarSatti
    * @package     QaisarSatti_HelloWorld
    * @author      Muhammad Qaisar Satti
    * @Email       qaisarssatti@gmail.com
    *
 */

namespace Itc\Hotels\Model;



class Room extends \Magento\Framework\Model\AbstractModel  
{   
	protected function _construct()
	{
		$this->_init('Itc\Hotels\Model\ResourceModel\Room');
	}
	
}