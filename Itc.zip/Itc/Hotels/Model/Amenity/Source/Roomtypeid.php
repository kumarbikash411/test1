<?php
/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Itc\Hotels\Model\Room\Source;

use Magento\Framework\Data\OptionSourceInterface;
use Itc\Hotels\Model\Roomtype;

/**
 * Class PageLayout
 */
class Roomtypeid implements OptionSourceInterface
{
    /**
     * @var \Magento\Framework\View\Model\PageLayout\Config\BuilderInterface
     */
    protected $roomtype;

    /**
     * @var array
     */
    protected $options;

    /**
     * Constructor
     *
     * @param BuilderInterface $pageLayoutBuilder
     */
    public function __construct(Roomtype $roomtype)
    {
        $this->roomtype = $roomtype;
    }

    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        if ($this->options !== null) {
            return $this->options;
        }

        $roomtypeOptions = $this->roomtype->getCollection()->getData();
        $options = [];
        foreach ($roomtypeOptions as $val) {
			$value = $val['room_type_name'];
			$key = $val['roomtype_id'];
            $options[] = [
                'label' => $value,
                'value' => $key,
            ];
        }
        $this->options = $options;

        return $this->options;
    }
}
