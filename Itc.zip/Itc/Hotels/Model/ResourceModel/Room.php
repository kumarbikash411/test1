<?php
/**
 * Hello World
    *
    * @category    QaisarSatti
    * @package     QaisarSatti_HelloWorld
    * @author      Muhammad Qaisar Satti
    * @Email       qaisarssatti@gmail.com
    *
 */


namespace Itc\Hotels\Model\ResourceModel;


use \Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Room extends AbstractDb

{
    protected function _construct()

    {
        $this->_init('itc_rooms', 'room_id');

    }
}